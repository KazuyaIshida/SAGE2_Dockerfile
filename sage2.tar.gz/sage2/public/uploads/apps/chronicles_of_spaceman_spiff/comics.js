// list of comics to view
// current limit is 5 comics

var SAGE2_comics = [];
SAGE2_comics[0] = {comicUrl: "http://www.gocomics.com/calvinandhobbes/",
					label:"C&H",
					comicName: "Calvin and Hobbes"};
SAGE2_comics[1] = {comicUrl: "http://www.gocomics.com/doonesbury/",
					label:"Doon",
					comicName: "Doonesbury"};
SAGE2_comics[2] = {comicUrl: "http://www.gocomics.com/dilbert-classics/",
					label:"Dilb",
					comicName: "Dilbert"};
SAGE2_comics[3] = {comicUrl: "http://www.gocomics.com/wizard-of-id-classics/",
					label:"WizId",
					comicName: "Wizard of Id"};
SAGE2_comics[4] = {comicUrl: "http://www.gocomics.com/bloomcounty/",
					label:"Blm",
					comicName: "Bloom County"};