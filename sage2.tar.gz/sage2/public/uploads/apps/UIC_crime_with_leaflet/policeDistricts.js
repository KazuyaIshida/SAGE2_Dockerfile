// list of chicago police districts to show on the map
// map available at http://gis.chicagopolice.org/pdfs/district_beat.pdf

SAGE2_policeDistricts = [
	"1232", 
	"1231", 
	"0124",
	"1224",
	"0121",
	"1233"
	];