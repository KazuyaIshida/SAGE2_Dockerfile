function googleMapsForSAGE2Init() {
	console.log("Google Maps API loaded");
}