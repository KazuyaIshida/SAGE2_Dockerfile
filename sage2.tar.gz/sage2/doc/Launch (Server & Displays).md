### Starting SAGE2 with one button

**Last revision:** 13 June 2014

##### Windows
* Single Machine
    * Create file 'GO-<server_name>.bat' and save in '<SAGE2_directory>/GO-scripts'

##### Mac OSX
* Single Machine
    * Create file 'GO-<server_name>' and save in '<SAGE2_directory>/GO-scripts'

##### openSUSE
* Single Machine
    * Create file 'GO-<server_name>' and save in '<SAGE2_directory>/GO-scripts'
* Cluster
    * Create file 'GO-<server_name>' and save in '<SAGE2_directory>/GO-scripts'

##### Ubuntu
* Single Machine
    * Create file 'GO-<server_name>' and save in '<SAGE2_directory>/GO-scripts'
