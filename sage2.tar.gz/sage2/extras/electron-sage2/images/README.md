Some icons:

Web Navigation Line Craft 50 icons
Freepik
by Freepik  
License: Flaticon Basic License 

