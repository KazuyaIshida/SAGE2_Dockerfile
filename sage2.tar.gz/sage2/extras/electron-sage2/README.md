# electron for SAGE2

**Experiment in an alternative desktop UI**

